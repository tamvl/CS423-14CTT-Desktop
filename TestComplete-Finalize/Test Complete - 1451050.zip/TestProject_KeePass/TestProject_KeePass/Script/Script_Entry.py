﻿def SettingEntry():
    #Runs the "KeePass" tested application.
    TestedApps.KeePass.Run()
    #Enters the text 'r' in the 'm_tbPassword' text editor.
    Aliases.KeePass.KeyPromptForm.m_tbPassword.SetText("r")
    #Enters the text '●x' in the 'm_tbPassword' text editor.
    Aliases.KeePass.KeyPromptForm.m_tbPassword.SetText("●x")
    #Clicks the 'm_btnOK' button.
    Aliases.KeePass.KeyPromptForm.m_btnOK.ClickButton()
    #Clicks at point (52, 92) of the 'm_lvEntries' object with the right mouse button.
    Aliases.KeePass.MainForm.m_splitHorizontal.SplitterPanel.m_splitVertical.SplitterPanel2.m_lvEntries.ClickR(52, 92)
    #Moves the mouse cursor to the menu item specified and then simulates a single click.
    Aliases.KeePass.MainForm.m_splitHorizontal.SplitterPanel.m_splitVertical.SplitterPanel2.m_lvEntries.StripPopupMenu.Click("Add Entry...")
    #Selects the 'Entry' tab of the 'm_tabMain' tab control.
    Aliases.KeePass.PwEntryForm.m_tabMain.ClickTab("Entry")
    #Enters the text 'testing1' in the 'm_tbTitle' text editor.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_tbTitle.SetText("testing1")
    #Clicks at point (109, 11) of the 'm_tbUserName' object.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_tbUserName.Click(109, 11)
    #Enters the text 'testings' in the 'm_tbUserName' text editor.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_tbUserName.SetText("testings")
    #Sets the state of the 'm_cbHidePassword' check box to cbUnchecked.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_cbHidePassword.wState = cbUnchecked
    #Clicks the 'm_btnIcon' button.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_btnIcon.ClickButton()
    #Clicks the 0 subitem of the '2' item of the 'm_lvIcons' list view.
    Aliases.KeePass.IconPickerForm.m_lvIcons.ClickItem("2")
    #Clicks the 'm_btnOK' button.
    Aliases.KeePass.IconPickerForm.m_btnOK.ClickButton()
    #Sets the state of the 'm_cbExpires' check box to cbChecked.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_cbExpires.wState = cbChecked
    #Clicks at point (24, 9) of the 'm_dtExpireDateTime' object.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabEntry.m_dtExpireDateTime.Click(24, 9)
    #Selects the 'Advanced' tab of the 'm_tabMain' tab control.
    Aliases.KeePass.PwEntryForm.m_tabMain.ClickTab("Advanced")
    #Selects the 'Properties' tab of the 'm_tabMain' tab control.
    Aliases.KeePass.PwEntryForm.m_tabMain.ClickTab("Properties")
    #Sets the state of the 'm_cbCustomBackgroundColor' check box to cbChecked.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabProperties.m_cbCustomBackgroundColor.wState = cbChecked
    #Clicks the 'm_btnPickBgColor' button.
    Aliases.KeePass.PwEntryForm.m_tabMain.m_tabProperties.m_btnPickBgColor.ClickButton()
    #Clicks at point (23, 81) of the 'dlgColor' object.
    Aliases.KeePass.dlgColor.Click(23, 81)
    #Clicks the 'btnOK' button.
    Aliases.KeePass.dlgColor.btnOK.ClickButton()
    #Selects the 'Auto-Type' tab of the 'm_tabMain' tab control.
    Aliases.KeePass.PwEntryForm.m_tabMain.ClickTab("Auto-Type")
    #Selects the 'History' tab of the 'm_tabMain' tab control.
    Aliases.KeePass.PwEntryForm.m_tabMain.ClickTab("History")
    #Selects the 'Advanced' tab of the 'm_tabMain' tab control.
    Aliases.KeePass.PwEntryForm.m_tabMain.ClickTab("Advanced")
    #Clicks the 'm_btnOK' button.
    Aliases.KeePass.PwEntryForm.m_btnOK.ClickButton()
