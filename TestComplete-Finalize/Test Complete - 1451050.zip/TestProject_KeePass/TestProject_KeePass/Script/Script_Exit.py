﻿def Exit():
    #Runs the "KeePass" tested application.
    TestedApps.KeePass.Run()
    #Clicks the 'm_btnCancel' button.
    Aliases.KeePass.KeyPromptForm.m_btnCancel.ClickButton()
    #Closes the 'MainForm' window.
    Aliases.KeePass.MainForm.Close()
    Log.Message("Script test to exit the application.")
