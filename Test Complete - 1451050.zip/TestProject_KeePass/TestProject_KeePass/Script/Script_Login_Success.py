﻿def Login_Success():
    #Runs the "KeePass" tested application.
    TestedApps.KeePass.Run()
    #Rotates the mouse wheel to -1 over the 'FolderView' object.
    Aliases.explorer.wndProgman.SHELLDLL_DefView.FolderView.MouseWheel(-1)
    #Rotates the mouse wheel to -1 over the 'FolderView' object.
    Aliases.explorer.wndProgman.SHELLDLL_DefView.FolderView.MouseWheel(-1)
    #Clicks at point (198, 10) of the 'KeyPromptForm' object.
    Aliases.KeePass.KeyPromptForm.Click(198, 10)
    #Clicks at point (89, 9) of the 'm_tbPassword' object.
    Aliases.KeePass.KeyPromptForm.m_tbPassword.Click(89, 9)
    #Enters 'r' in the 'm_tbPassword' object.
    Aliases.KeePass.KeyPromptForm.m_tbPassword.Keys("r")
    #Sets the state of the 'm_cbPassword' check box to cbChecked.
    Aliases.KeePass.KeyPromptForm.m_cbPassword.wState = cbChecked
    #Clicks at point (31, 12) of the 'm_tbPassword' object.
    Aliases.KeePass.KeyPromptForm.m_tbPassword.Click(31, 12)
    #Enters the text '●x' in the 'm_tbPassword' text editor.
    Aliases.KeePass.KeyPromptForm.m_tbPassword.SetText("●x")
    #Clicks the 'm_btnOK' button.
    Aliases.KeePass.KeyPromptForm.m_btnOK.ClickButton()
    Log.Message("Script test to login successfully.")